# Resto Cashier POS

dont copy our code. i have a laweryer

![Current look](https://dr5j5pergsi3v.cloudfront.net/kqsl%2Fpreview%2F49725884%2Fmain_full.png?response-content-disposition=inline%3Bfilename%3D%22main_full.png%22%3B&response-content-type=image%2Fpng&Expires=1673266194&Signature=WoRwTaPFAOMn-NkzEY2oFdzDFbqrFPB7UZqkB337xZF48Sw9lk0B4~LfYS-51xBM187j64KzVHAIkN3603~6XxSSQq0IPumhmMci2JE2ohonq7URj2iWVK7L9q9yyEw9V2rHtVwnAgNRIi7nNe-IOpVpjZP1CpfZzr6gQeBhn1zrvnFzhxKKkqr2GOmLoL7Mk-i3HuQ2A5FOIx~CQxzjGUIOvXayUtsA4ePt2PDx~UuwlaDKtSLP-8vdTOKXvAW3xVp1uD0dzDOj2~4eNUXv6gvKvJ49sW6fSmsGeZTpIH1wLqP0irt8Nb7BNM~t6PwJ05Dn7T-SP3a~skDTYAP6XA__&Key-Pair-Id=APKAJT5WQLLEOADKLHBQ)