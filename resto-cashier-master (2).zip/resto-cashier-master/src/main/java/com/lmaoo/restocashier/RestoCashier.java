/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.lmaoo.restocashier;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author Seifer
 */
public class RestoCashier extends JFrame implements ActionListener {
    private POSBackend backend;
    private final ArrayList<Product> order = new ArrayList<>();
    
    private JButton btnOrder;
    private JPanel pnlOrder;
    private JPanel pnlProducts;
    private JTable j;
    DefaultTableModel model;
    private JTextField txtTotalAmount;
    private JLabel lblTotalAmount;
    
    public RestoCashier() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Resto Cashier");
        
        generateProductsPanel();
        generateOrderList();
        generateOrderButton();
 
         btnOrder.setText("Order");
 
         GroupLayout layout = new GroupLayout(getContentPane());
         getContentPane().setLayout(layout);
         layout.setHorizontalGroup(
             layout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(layout.createSequentialGroup()
                 .addContainerGap()
                 .addComponent(pnlProducts, GroupLayout.PREFERRED_SIZE, 500, GroupLayout.PREFERRED_SIZE)
                 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                 .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addComponent(pnlOrder, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                     .addComponent(btnOrder, GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE))
                 .addContainerGap())
         );
         layout.setVerticalGroup(
             layout.createParallelGroup(GroupLayout.Alignment.LEADING)
             .addGroup(layout.createSequentialGroup()
                 .addContainerGap()
                 .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                     .addGroup(layout.createSequentialGroup()
                         .addComponent(pnlOrder, GroupLayout.PREFERRED_SIZE, 500, GroupLayout.PREFERRED_SIZE)
                         .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
                         .addComponent(btnOrder, GroupLayout.DEFAULT_SIZE, 82, Short.MAX_VALUE))
                     .addComponent(pnlProducts, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                 .addContainerGap())
         );
         
        pack();
    }
    
    final void generateOrderButton() {
        btnOrder = new JButton("Create Order");
        pnlOrder.add(btnOrder);
        
        // TODO open new window with order
       
    }
    
    /**
     * Author: Seifer Albacete
     * Description: Create Products panel (grid of buttons)
     */
    final void generateProductsPanel() {
        pnlProducts = new JPanel(); 
        pnlProducts.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); 
        
        // Products panel
        GridLayout layout = new GridLayout(5, 5, 5, 5);
        pnlProducts.setLayout(layout);

        loadProducts();
    }
    
    final void generateOrderList() {
        pnlOrder = new JPanel();
        
        BoxLayout layout = new BoxLayout(pnlOrder, BoxLayout.Y_AXIS);
        pnlOrder.setLayout(layout);
        
        //create Table
        CreateTable();
        
        //textbox for total
        lblTotalAmount = new JLabel();
        lblTotalAmount.setText("Total Amount");
        lblTotalAmount.setHorizontalAlignment(SwingConstants.CENTER);
        JScrollPane sp = new JScrollPane(lblTotalAmount);
        
        
        txtTotalAmount = new JTextField();
        txtTotalAmount.setForeground(Color.RED);
        txtTotalAmount.setFont(new Font("Serif", Font.PLAIN, 25));
        txtTotalAmount.setHorizontalAlignment(SwingConstants.RIGHT);
        JScrollPane sp1 = new JScrollPane(txtTotalAmount);

        pnlOrder.add(sp);
        pnlOrder.add(sp1);
    }
    
    public void CreateTable()
    {
       String[] columnNames = { "Product Name", "Qty", "Price", "Total Amount" };
         model = new DefaultTableModel(columnNames, 0);
        j = new JTable( model );
        //adding it to JScrollPane
        JScrollPane sp = new JScrollPane(j);
        pnlOrder.add(sp);
        
    }
    
    
    
    
 
    void loadProducts() {
        backend = new POSBackend(); // load data from json file
         
         var products = backend.getProducts();
         for (var product : products) {            
             JButton productBtn = new JButton(product.getName());
             productBtn.addActionListener(e -> addToOrder(product));
             pnlProducts.add(productBtn);
             
             productBtn.addActionListener(this);
         }
    }
    
    void addToOrder(Product product) {
        order.add(product);
        regeneratePanel(pnlOrder); // required to make things show
    }

    // helper functions
    final void regeneratePanel(JPanel panel) {
        panel.revalidate();
        panel.repaint();
        pack();
    }
    public static void main(String[] args) {
         EventQueue.invokeLater(() -> {
             new RestoCashier().setVisible(true);
         });
    }
    
   
   int ctr=0;
   double totalAmt=0;
   double totalprice=0;
   int prodname=1;
   int prodprice=0;
   String[] arr = new String[100]; 
   double[] arrprice = new double[100]; 
   int[] arrcounter = new int[100]; 
   int rowno;
   int qty;
   double price;
   double totalamount;
  
  @Override
    public void actionPerformed(ActionEvent e) {
       
         var products = backend.getProducts();
         
         for (var product : products) {
             arr[prodname] = product.getName();
             arrprice[prodprice] = product.getPrice();
             
           if(e.getActionCommand().equals(arr[prodname]))
               {
                   totalAmt =  1 * arrprice[prodprice];
                   Object[] row = {arr[prodname], 1,arrprice[prodprice], totalAmt};
    
                   
                  int rows = model.getRowCount(); //get number of rows in table
                  if(rows == 0)
                  {
                      model.addRow(row);
                      txtTotalAmount.setText(String.valueOf(totalAmt));
                  }
                  else
                  {
                        //check if there is product name same with the Action command 
                          int check=0;
                          qty = 0;
                          price = 0;
                          
                          for (int index = 0; index < rows; index++) {
                             String cellValue = model.getValueAt(index, 0).toString();
                             if(e.getActionCommand().equals(cellValue))
                             {
                               check++;   
                               rowno = index;
                               qty = Integer.parseInt(model.getValueAt(index, 1).toString());
                               price = Double.parseDouble(model.getValueAt(index, 2).toString());
                             }  
                          }
                          
                          //check if there is already product name in the table then update else add the product to the table
                          if(check >0)
                          {
                              //Update table
                              totalamount = (qty + 1) * price;              
                              model.setValueAt(qty + 1, rowno, 1);
                              model.setValueAt(totalamount, rowno, 3);
                              //JOptionPane.showMessageDialog(this, arr[prodname] + " *****UPDATE****** " + check);     
                          }
                          else
                          {
                               model.addRow(row);
                               
                              //JOptionPane.showMessageDialog(this, arr[prodname] + " ***ADD ****" + check); 
                          }
                  }
                  
                  //Final Total Amount
                    int rowtablecnt = model.getRowCount();
                    double AllAmt ,grandtotal = 0;
                    
                   for (int index = 0; index < rowtablecnt; index++) 
                   {
                       AllAmt = Double.parseDouble(model.getValueAt(index, 3).toString());
                       grandtotal = grandtotal + AllAmt;
                       
                   }
                   txtTotalAmount.setText(String.valueOf(grandtotal));
                   
            }
                  
         }
    
    }

}
